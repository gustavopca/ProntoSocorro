package br.com.fila;

import br.com.atendimento.Paciente;

public class FilaPrioridade<T> extends Fila<T> {

	public FilaPrioridade(int capacidade) {
		super(capacidade);
	}
	public void enfileira(T elemento) {
		Comparable<T> chave = (Comparable<T>) elemento;
		int a;
		for(a=0; a < this.tamanho; a++){
			if(chave.compareTo(this.elementos[a]) < 0) {
				break;
			}
		}
		this.adiciona(a, elemento);
	}
	
}
