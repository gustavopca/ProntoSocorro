package br.com.atendimento;

public class Medico {
	String nome;
	int crm;
	String especialidade;
	String usuario;
	String senha;
	
	public Medico(String nome, int crm, String especialidade, String usuario, String senha) {
		super();
		this.nome = nome;
		this.crm = crm;
		this.especialidade = especialidade;
		this.usuario = usuario;
		this.senha = senha;
	}

	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getCrm() {
		return crm;
	}
	public void setCrm(int crm) {
		this.crm = crm;
	}
	public String getEspecialidade() {
		return especialidade;
	}
	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public String toString() {
		return String.format("\nNome: " + nome + "\nCRM: " + especialidade +"\nEspecialidade: " + especialidade +  "\nUsuario: " + usuario);
	}


	
}
