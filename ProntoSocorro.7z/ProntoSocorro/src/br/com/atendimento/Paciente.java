package br.com.atendimento;


public class Paciente {
	String nome;
	float temperatura;
	int pressao;
	String email;
	String condicao;
	String sintomas;
	int prioridade;
	
	public Paciente(String nome, float temperatura, int pressao, String email, String condicao, String sintomas, int prioridade) {
		this.nome = nome;
		this.temperatura = temperatura;
		this.pressao = pressao;
		this.email = email;
		this.condicao = condicao;
		this.sintomas = sintomas;
		this.prioridade = prioridade;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getTemperatura() {
		return temperatura;
	}
	public void setTemperatura(int temperatura) {
		this.temperatura = temperatura;
	}
	public int getPressao() {
		return pressao;
	}
	public void setPressao(int pressao) {
		this.pressao = pressao;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCondicao() {
		return condicao; 
	}
	public void setCondicao(String condicao) {
		this.condicao = condicao;
	}
	public String getSintomas() {
		return sintomas;
	}
	public void setSintomas(String sintomas) {
		this.sintomas = sintomas;
	}
	public int getPrioridade() {
		return prioridade;
	}
	public void setPrioridade(int prioridade) {
		this.prioridade = prioridade;
	}

	
	public String toString() {
		return String.format("\nNome: " + nome + "\nTemperatura: " + temperatura +"\nPress�o: " + pressao +  "\nE-mail: " + email + "\nCondi��o: " + condicao + "\nSintomas: " + sintomas);
				}

	public int compareTo(Paciente p) {
		if(this.prioridade > p.getPrioridade()) {
			return 1;
		}else if(this.prioridade < p.getPrioridade()) {
			return -1;
		}
		return 0;
	}
	
}
