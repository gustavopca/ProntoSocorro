package br.com.principal;

import java.util.Scanner;
import br.com.atendimento.Medico;
import br.com.atendimento.Paciente;
import br.com.fila.FilaPrioridade;

public class Principal {
	static Scanner scan = new Scanner(System.in);
	static FilaPrioridade<Object> fila = new FilaPrioridade<Object>(0);
	static Medico[] medico = new Medico[10];
	static int contMedico = 0;
	
	public static void main(String[] args) {
		int cadastrar = 0;
		int operador = 0;
		
		do {
			System.out.println("Menu");
			System.out.println("1. Operador.");
			System.out.println("2. M�dico.");
			System.out.println("3. Sair.");
			operador = scan.nextInt();
			
			switch (operador) {
					
			case 1:
				do {
					limpaTela();
					System.out.println("Menu de op��es: ");
					System.out.println("1. Adicionar paciente.");
					System.out.println("2. Adicionar o m�dico");
					System.out.println("3. Voltar");
					cadastrar = scan.nextInt();
					
					if(cadastrar == 1) {
						cadastrarCliente();
					}else if(cadastrar == 2) {
						cadastrarMedico();
					}else if(cadastrar == 3) {
						System.out.println("...");
					}else {
						System.out.println("INV�LIDO");
					}
					
				} while (cadastrar != 3);
				
				break;
			case 2:
				limpaTela();
				if(contMedico == 0) {
					System.out.println("Cadastre um m�dico no sistema!");
					break;
				}
				medico();
				break;
				
			case 3:
				System.out.println("...");
				break;
			default:
				System.out.println("INV�LIDO");
				break;
			}
			limpaTela();
		} while (operador!= 3);
	}

	public static void cadastrarCliente() {
		int pressao;
		float temperatura;
		int opc;
		String nome, email, condicao, sintoma;
		
		System.out.print("Nome do paciente: ");
		nome = scan.next();
		System.out.print("Temperatura: ");
		temperatura = scan.nextFloat();
		System.out.print("Press�o: ");
		pressao = scan.nextInt();
		System.out.print("E-mail: ");
		email = scan.next();
		System.out.print("Condi��o do paciente: \n1. Vermelho\n2. Amarelo\n3. Verde\n4. Azul\n");opc = scan.nextInt();
		if(opc == 1) {
			condicao = "Vermelho";
		} else if(opc == 2) {
			condicao = "Amarelo";
		} else if(opc == 3) {
			condicao = "Verde";
		} else {
			condicao = "Azul";
		}
		System.out.print("Sintomas do paciente: ");
		sintoma = scan.next();
		fila.enfileira(new Paciente(nome,temperatura,pressao,email,condicao,sintoma, opc));
		}
	
	public static void cadastrarMedico() {
		int crm;
		String nome, especi, user, password;
		System.out.print("Nome do M�dico: ");
		nome = scan.next();
		System.out.print("CRM: ");
		crm = scan.nextInt();
		System.out.print("Especialidade: ");
		especi = scan.next();
		System.out.print("Usu�rio: ");
		user = scan.next();
		System.out.print("Senha: ");
		password = scan.next();
		medico[contMedico] = new Medico(nome, crm, especi, user, password);
		contMedico++;
	}
	
	private static void medico() {
		String user;
		String senha;
		int opc;
		boolean b = false;
		do {
			System.out.println("Usu�rio: ");
			user = scan.next();
			System.out.println("Senha: ");
			senha = scan.next();
		for(opc = 0; opc < contMedico; opc++) {
			if(medico[opc].getUsuario().equals(user) && medico[opc].getSenha().equals(senha) ) {
				b = true;
				break;
			}
		}
		if(b) {
			System.out.println("Ol� doutor: " + medico[opc].getNome());
			atender();
		}else {
			System.out.println("INV�LIDO");
		}
		} while (b == false);
	}

	private static void atender() {
		int opc = 0;
		do {
			System.out.println("Menu:");
			System.out.println("1. Chamar paciente.");
			System.out.println("2. Listar pacientes.");
			System.out.println("3. Sair.");
			opc = scan.nextInt();
			
			switch (opc) {
				case 1:
					System.out.println("Paciente: " + fila.desinfileira());
					break;
					
				case 2:
					System.out.println(fila.toString());
					
					break;
					
				case 3:
					System.out.println("Sair");
					break;
					
				default:
					System.out.println("INV�LIDO");
					break;
			}
			
		} while (opc != 3);
	}
	
	public static void limpaTela() {
		for(int i = 0; i < 50; i++) {
			System.out.println();
		}
	}
}
